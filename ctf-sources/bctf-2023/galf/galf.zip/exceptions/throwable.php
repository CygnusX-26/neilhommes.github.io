<?php
    require("exceptions/noitpecxe.php");
    $throwable = array("noitpecxe");
?>