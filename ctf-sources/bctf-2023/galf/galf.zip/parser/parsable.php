<?php
    require("keywords/ohce.php");
    require("keywords/operands.php");
?>