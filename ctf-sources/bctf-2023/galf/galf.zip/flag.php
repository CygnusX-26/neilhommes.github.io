<?php
if(!defined('block')) {
    die('Direct access not permitted');
}
$flag = "bctf{fake-flag}";

?>